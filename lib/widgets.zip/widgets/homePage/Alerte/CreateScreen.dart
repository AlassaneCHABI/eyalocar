import 'package:eyalocar/constants.dart';
import 'package:flutter/material.dart';
import 'package:eyalocar/widgets/homePage/Alerte/body.dart';

class CreateAlerteScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Nouvelle Alerte"),
        backgroundColor: kPrimaryColor,
      ),
      body: Body(),
    );
  }
}
